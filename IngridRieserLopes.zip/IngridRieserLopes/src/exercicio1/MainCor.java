package exercicio1;

public class MainCor {
    public static void main(String[] args) {
        Cor cor = new Cor();

        cor.adicionarCor();
        cor.listarCores();
    }
}
